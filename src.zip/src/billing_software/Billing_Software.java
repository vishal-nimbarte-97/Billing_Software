
package billing_software;

public class Billing_Software 
{

    public static void main(String[] args)
    {
        StartProject sp = new StartProject();
        sp.setVisible(true);
    }
    
}
